import random

random_number = random.randint(1, 10)
print(random_number)
